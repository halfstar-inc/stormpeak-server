# Stormpeak multiplayer server

Upload the contents of this folder to a GitHub repository, keeping `render.yaml` and `coop-server/` at the repository root. In Render select New > Blueprint and connect the repository. The blueprint configures a free Node web service.

After deployment, visit https://YOUR-SERVICE.onrender.com/health and confirm the response contains `"ok":true`. The game must be re-exported with `server_url` set to wss://YOUR-SERVICE.onrender.com in online_config.json.

The server supports two-player rooms. Free hosting can sleep; wake the health URL before hosting a game. Deployment restarts end active rooms.
